const express = require('express');
const router = express.Router();
const Post = require('../models/posts')
const mongoose = require('mongoose');
const multer = require('multer');
const checkAuth =require('../middleware/check-auth');




const storage = multer.diskStorage({
    destination:function(req, file,cb){
        cb(null,'./uploads/');
    },
    filename:function(req,file,cb){

        cb(null,new Date().toISOString()+ file.originalname);
    }
});


const upload = multer({storage:storage, limits:{
    fileSize:1024*1024*10
}});


router.get('/', (req ,res, next)=>{
  Post.find()
  .select('Description Category _id')
  .exec()
  .then(docs=>{
    const response ={
        count:docs.length,
        events:docs.map(doc=>{
            return{
              Description:doc.Description,
              Category:doc.Category,
              PostPic:doc.PostPic,
              _id:doc._id,
              request:{
                type:'GET',
                url:'http://localhost:3000/posts/'+ doc._id      
              }

            }
        })
    };
    res.status(200).json(response);
  })
  .catch(err=>{
      console.log(err);
      res.status(500).json({
          error:err
      });
  });


});

router.post('/', checkAuth, upload.single('postPic'), (req ,res, next)=>{
    console.log(req.file);
    
    const post = new Post({
        Description: req.body.Description,
        Category:req.body.Category,
        PostPic:req.file.path,
        PostBy:req.body.PostBy
        
        

    });
    post.save().then(result=>{
        console.log(result);
        })
        .catch(err=> console.log(err));
        res.status(201).json({
            message:"Your post was submitted successfully",
            createdPostfeed: post
        });

    });

router.get('/:postID',(req ,res, next)=>{
  const id = req.params.postID;
    Post.findById(id)
    .exec()
    .then(doc=>{
        console.log(doc);
        if (doc){
            res.status(200).json(doc);
        }
        else {
          res.status(404).json({message:'No valid entry found for provided ID'});
        }
    })
    .catch(err=>{
        console.log(err);
        res.status(500).json({
            error:err
        });
    });
    
  
});

router.patch('/:postID',(req ,res, next)=>{
        const id = req.params.postID;
        const updateOps ={};
        
        for (const ops of req.body){
            updateOps[ops.propName]=ops.value;
        }

    Post.update({_id:id}, {$set:updateOps})
    .exec()
    .then(result=>{
        console.log(result);
        res.status(200).json(result);
    })
    .catch(err=>{
        console.log(err);
        res.status(500).json({
            error:err
        });
  
  });
  
});

  router.delete('/:postID',(req ,res, next)=>{
      const id = req.params.postID;
  Post.remove({_id:id})
  .exec()
  .then(result=>{
      res.status(200).json(result);
  })
  .catch(err=>{
      console.log(err);
      res.status(500).json({
          error:err
      });
  });
   
});
  
module.exports = router;