const express = require('express');
const router = express.Router();
const User = require('../models/users')
const mongoose = require('mongoose');
const multer = require('multer');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const storage = multer.diskStorage({
    destination:function(req, file,cb){
        cb(null,'./profiles/');
    },
    filename:function(req,file,cb){

        cb(null,new Date().toISOString()+ file.originalname);
    }
});


const upload = multer({storage:storage, limits:{
    fileSize:1024*1024*10
}});


router.get('/', (req ,res, next)=>{
    User.find()
    .select('FullNames NickName DOB Country UniversityName Level Faculty Course Email ProfilePic ')
    .exec()
    .then(docs=>{
      const response ={
          count:docs.length,
          users:docs.map(doc=>{
              return{
                FullNames:doc.FullNames,
                NickName:doc.NickName,
                DOB: doc.DOB,
                Country:doc.Country,
                UniversityName:doc.UniversityName,
                UniversityInitials:doc.UniversityInitials,
                Level:doc.Level,
                Faculty:doc.Faculty,
                Course:doc.Course,
                Email:doc.Email,
                ProfilePic:doc.ProfilePic,                
                _id:doc._id,
                
                request:{
                  type:'GET',
                  url:'http://localhost:3000/users/'+ doc._id      
                }

              }
          })
      };
      res.status(200).json(response);
    })
    .catch(err=>{
        console.log(err);
        res.status(500).json({
            error:err
        });
    });
  
  
  });

router.post('/signup', upload.single('profilePic'), (req ,res, next)=>{

    User.find({Email:req.body.Email})
    .exec()
    .then(user=>{
        if(user.length>=1){
            return res.status(409).json({
                message:'Email Exists'
            });
        }
        else {
                

    bcrypt.hash(req.body.Password,10,(err,hash)=>{
        if(err){
            res.status(500).json({
                error:err
            });
        }
        else{
            console.log(req.file);
            const user = new User(
        {
        FullNames: req.body.FullNames,
        NickName:req.body.NickName,
        DOB: req.body.DOB,
        Country:req.body.Country,
        UniversityName:req.body.UniversityName,
        UniversityInitials:req.body.UniversityInitials,
        Level:req.body.Level,
        Faculty:req.body.Faculty,
        Course:req.body.Course,
        ProfilePic:req.file.path,
        Email:req.body.Email,
        Password: hash
        });
    
        
        user.save()
        .then(result=>{
            console.log(result);
            res.status(201).json({
            message:"smartpal user was created successfully successfully",
                        
        });
    })
        .catch(err=>{
            console.log(err);
            res.status(500).json({
                error:err
            });
        });
        }
        });
        }
    })
               
    });


router.post('/login',(req,res, next)=>{
    User.find({Email:req.body.Email})
    .exec()
    .then(user=>{
            if(user.length<1){
                return res.status(401).json({
                    message: 'Auth Failed'
                });
            }
            
            bcrypt.compare(req.body.Password, user[0].Password,(err,result)=>{

                if(err){
                    return res.status(401).json({
                        message: 'Auth Failed'
                    });
                }
                if(result){

                   const token = jwt.sign({
                        userId:user[0]._id,
                        FullNames:user[0].FullNames,
                        
                    }
                    ,process.env.JWT_KEY,
                    {
                        expiresIn:"1h"
                    }
                
                    );

                    return res.status(200).json({
                  message:'Auth successfull',
                  token:token,
                    });

                }
                res.status(401).json({
                    message: 'Auth Failed'
                });
            });

    })
    .catch(err=>{
        console.log(err);
        res.status(500).json({
            error:err
        });
    });
});


router.get('/:userID',(req ,res, next)=>{
    const id = req.params.userID;
    User.findById(id)
    .exec()
    .then(doc=>{
        console.log(doc);
        if (doc){
            res.status(200).json(doc);
        }
        else {
          res.status(404).json({message:'No valid entry found for provided ID'});
        }
    })
    .catch(err=>{
        console.log(err);
        res.status(500).json({
            error:err
        });
    });
    
  
});

router.patch('/:userID',(req ,res, next)=>{
  
    const id = req.params.userID;
    const updateOps ={};
    
    for (const ops of req.body){
        updateOps[ops.propName]=ops.value;
    }

User.update({_id:id}, {$set:updateOps})
.exec()
.then(result=>{
    console.log(result);
    res.status(200).json(result);
})
.catch(err=>{
    console.log(err);
    res.status(500).json({
        error:err
    });

});

});

  router.delete('/:userID',(req ,res, next)=>{
    const id = req.params.userID;
    User.remove({_id:id})
    .exec()
    .then(result=>{
        res.status(200).json({
            message:'User Deleted'
        });
    })
    .catch(err=>{
        console.log(err);
        res.status(500).json({
            error:err
        });
    });
     
  });
  
module.exports = router;