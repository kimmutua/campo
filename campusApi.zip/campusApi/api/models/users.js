const mongoose = require('mongoose');
const userSchema = mongoose.Schema({
    
    
    FullNames:{type:String,required:true},
    NickName: {type:String},
    DOB: {type:Date,required:true},
    Country:{type:String,required:true},
    UniversityName:{type:String,required:true},
    UniversityInitials:{type:String},
    Level:{type:String,required:true},
    Faculty:{type:String,required:true},
    Course:{type:String,required:true},
    ProfilePic:{type:String},
    Email:{
        type:String,
        required:true,
        unique:true,
        match:/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/
    },
    Password:{type:String,required:true}



});


module.exports = mongoose.model('User', userSchema);