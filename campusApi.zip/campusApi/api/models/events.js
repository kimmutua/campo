const mongoose = require('mongoose');
const eventSchema = mongoose.Schema({

Description:{type:String,required:true},
Category:String,
EventDate:{type:Date,required:true,default: Date.now},
StartTime: {type:Date,required:true},
EndTime:{type:Date,required:true},
Location:String,
EventImage:String,
PostBy:{type:mongoose.Schema.Types.ObjectId,required:true, ref:'User'}
});


module.exports = mongoose.model('Event', eventSchema);