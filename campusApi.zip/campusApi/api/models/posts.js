const mongoose = require('mongoose');
const postSchema = mongoose.Schema({
Description:String,
Category:String,
PostPic:String,
PostBy:{type:mongoose.Schema.Types.ObjectId,required:true, ref:'User'}
});


module.exports = mongoose.model('Post', postSchema);